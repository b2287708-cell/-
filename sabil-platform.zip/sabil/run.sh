#!/usr/bin/env bash
# تشغيل سريع: ./run.sh   ثم افتح http://127.0.0.1:5000
set -e
cd "$(dirname "$0")"
python3 -m pip install -q -r requirements.txt 2>/dev/null || true
exec python3 app.py
