"""طبقة الدفع.

لا تلمس هذه المنصة أي أموال حقيقية بشكل افتراضي:

* DemoProvider   : يسجّل التبرع كـ «مؤكد» فورًا للتجربة والعرض (الوضع الافتراضي).
* ManualProvider : يسجّل التبرع كـ «بانتظار التأكيد»، ويؤكده المدير من لوحة الإدارة
                   بعد وصول المبلغ فعلًا (تحويل محفظة / إنستا باي / حساب بنكي).

لربط بوابة دفع حقيقية (Paymob أو Fawry أو Stripe ...) أنشئ صنفًا جديدًا يرث من
PaymentProvider وينفّذ charge()، ثم أضفه إلى PROVIDERS واضبط PAYMENT_PROVIDER.
لا تجمع أرقام البطاقات بنفسك أبدًا؛ استخدم صفحة الدفع المستضافة عند البوابة.
"""
import secrets
from dataclasses import dataclass


@dataclass
class PaymentResult:
    ok: bool
    status: str  # confirmed | pending | rejected
    reference: str
    message: str = ""


def new_reference():
    return "SB-" + secrets.token_hex(4).upper()


class PaymentProvider:
    name = "base"

    def charge(self, *, amount, method, donor_name, initiative_title):
        raise NotImplementedError


class DemoProvider(PaymentProvider):
    name = "demo"

    def charge(self, *, amount, method, donor_name, initiative_title):
        return PaymentResult(True, "confirmed", new_reference())


class ManualProvider(PaymentProvider):
    name = "manual"

    def charge(self, *, amount, method, donor_name, initiative_title):
        return PaymentResult(True, "pending", new_reference())


PROVIDERS = {"demo": DemoProvider, "manual": ManualProvider}


def get_provider(name):
    return PROVIDERS.get(name, DemoProvider)()
