"""قاعدة البيانات: SQLite مباشرة بدون ORM لتبقى المنصة خفيفة وواضحة."""
import os
import random
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone

from flask import current_app, g
from werkzeug.security import generate_password_hash

SCHEMA = """
CREATE TABLE IF NOT EXISTS initiatives (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  slug       TEXT UNIQUE NOT NULL,
  title      TEXT NOT NULL,
  summary    TEXT NOT NULL,
  story      TEXT NOT NULL DEFAULT '',
  category   TEXT NOT NULL,
  location   TEXT NOT NULL DEFAULT '',
  goal       INTEGER NOT NULL CHECK (goal > 0),
  unit_label TEXT NOT NULL DEFAULT '',
  unit_cost  INTEGER NOT NULL DEFAULT 0,
  cover_url  TEXT NOT NULL DEFAULT '',
  urgent     INTEGER NOT NULL DEFAULT 0,
  status     TEXT NOT NULL DEFAULT 'active',      -- active | completed | hidden
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS donations (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  donor_name    TEXT NOT NULL DEFAULT '',
  amount        INTEGER NOT NULL CHECK (amount > 0),
  message       TEXT NOT NULL DEFAULT '',
  anonymous     INTEGER NOT NULL DEFAULT 0,
  method        TEXT NOT NULL DEFAULT 'wallet',
  status        TEXT NOT NULL DEFAULT 'confirmed', -- pending | confirmed | rejected
  reference     TEXT UNIQUE NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_donations_init ON donations(initiative_id, status);
CREATE INDEX IF NOT EXISTS idx_donations_created ON donations(created_at);

CREATE TABLE IF NOT EXISTS volunteers (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  initiative_id INTEGER REFERENCES initiatives(id) ON DELETE SET NULL,
  name          TEXT NOT NULL,
  phone         TEXT NOT NULL,
  email         TEXT NOT NULL DEFAULT '',
  note          TEXT NOT NULL DEFAULT '',
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS updates (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  initiative_id INTEGER NOT NULL REFERENCES initiatives(id) ON DELETE CASCADE,
  body          TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);
"""


def now():
    return datetime.now(timezone.utc).replace(microsecond=0)


def iso(dt):
    return dt.isoformat(timespec="seconds")


# ---------------------------------------------------------------- الاتصال
def _connect(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = _connect(current_app.config["DATABASE"])
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    path = current_app.config["DATABASE"]
    conn = _connect(path)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA)
    _ensure_admin(conn)
    if current_app.config["SEED_DEMO"]:
        count = conn.execute("SELECT COUNT(*) FROM initiatives").fetchone()[0]
        if count == 0:
            _seed_demo(conn)
    conn.commit()
    conn.close()


def _ensure_admin(conn):
    if conn.execute("SELECT COUNT(*) FROM admins").fetchone()[0]:
        return
    username = os.getenv("ADMIN_USER", "admin")
    password = os.getenv("ADMIN_PASSWORD")
    generated = not password
    if generated:
        password = secrets.token_urlsafe(9)
    conn.execute(
        "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
        (username, generate_password_hash(password)),
    )
    if generated:
        print(f"\n[سبيل] تم إنشاء حساب المدير: {username} / {password}")
        print("[سبيل] احفظ كلمة المرور الآن، أو غيّرها بالأمر: flask --app app set-admin-password\n")


def set_admin_password(username, password):
    db = get_db()
    row = db.execute("SELECT id FROM admins WHERE username = ?", (username,)).fetchone()
    h = generate_password_hash(password)
    if row:
        db.execute("UPDATE admins SET password_hash = ? WHERE id = ?", (h, row["id"]))
    else:
        db.execute("INSERT INTO admins (username, password_hash) VALUES (?, ?)", (username, h))
    db.commit()


def get_admin(username):
    return get_db().execute("SELECT * FROM admins WHERE username = ?", (username,)).fetchone()


def get_admin_by_id(admin_id):
    return get_db().execute("SELECT * FROM admins WHERE id = ?", (admin_id,)).fetchone()


# ---------------------------------------------------------------- المبادرات
_INITIATIVE_SQL = """
SELECT i.*,
       COALESCE(SUM(CASE WHEN d.status = 'confirmed' THEN d.amount END), 0) AS raised,
       COUNT(CASE WHEN d.status = 'confirmed' THEN 1 END)                   AS donors
FROM initiatives i
LEFT JOIN donations d ON d.initiative_id = i.id
{where}
GROUP BY i.id
{order}
"""


def _initiative(row):
    d = dict(row)
    d["raised"] = int(d["raised"] or 0)
    d["donors"] = int(d["donors"] or 0)
    d["pct"] = min(100, int(d["raised"] * 100 / d["goal"])) if d["goal"] else 0
    d["remaining"] = max(0, d["goal"] - d["raised"])
    return d


def list_initiatives(category=None, q=None, include_hidden=False, limit=None):
    clauses, args = [], []
    if not include_hidden:
        clauses.append("i.status != 'hidden'")
    if category:
        clauses.append("i.category = ?")
        args.append(category)
    if q:
        clauses.append("(i.title LIKE ? OR i.summary LIKE ? OR i.location LIKE ?)")
        args += [f"%{q}%"] * 3
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    order = "ORDER BY (i.status = 'active') DESC, i.urgent DESC, i.created_at DESC"
    sql = _INITIATIVE_SQL.format(where=where, order=order)
    if limit:
        sql += f" LIMIT {int(limit)}"
    return [_initiative(r) for r in get_db().execute(sql, args).fetchall()]


def get_initiative(slug, include_hidden=False):
    where = "WHERE i.slug = ?" + ("" if include_hidden else " AND i.status != 'hidden'")
    row = get_db().execute(_INITIATIVE_SQL.format(where=where, order=""), (slug,)).fetchone()
    return _initiative(row) if row and row["id"] is not None else None


def get_initiative_by_id(initiative_id):
    row = get_db().execute(
        _INITIATIVE_SQL.format(where="WHERE i.id = ?", order=""), (initiative_id,)
    ).fetchone()
    return _initiative(row) if row and row["id"] is not None else None


def slug_exists(slug, exclude_id=None):
    row = get_db().execute("SELECT id FROM initiatives WHERE slug = ?", (slug,)).fetchone()
    return bool(row) and row["id"] != exclude_id


def save_initiative(data, initiative_id=None):
    db = get_db()
    cols = ("slug", "title", "summary", "story", "category", "location", "goal",
            "unit_label", "unit_cost", "cover_url", "urgent", "status")
    values = [data[c] for c in cols]
    if initiative_id:
        sets = ", ".join(f"{c} = ?" for c in cols)
        db.execute(f"UPDATE initiatives SET {sets} WHERE id = ?", values + [initiative_id])
        db.commit()
        return initiative_id
    cur = db.execute(
        f"INSERT INTO initiatives ({', '.join(cols)}, created_at) VALUES ({', '.join('?' * len(cols))}, ?)",
        values + [iso(now())],
    )
    db.commit()
    return cur.lastrowid


def delete_initiative(initiative_id):
    db = get_db()
    db.execute("DELETE FROM initiatives WHERE id = ?", (initiative_id,))
    db.commit()


# ---------------------------------------------------------------- التبرعات
def add_donation(initiative_id, donor_name, amount, message, anonymous, method, status, reference):
    db = get_db()
    cur = db.execute(
        """INSERT INTO donations
           (initiative_id, donor_name, amount, message, anonymous, method, status, reference, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (initiative_id, donor_name, amount, message, int(anonymous), method, status, reference, iso(now())),
    )
    db.commit()
    return cur.lastrowid


def get_donation_by_reference(reference):
    return get_db().execute("SELECT * FROM donations WHERE reference = ?", (reference,)).fetchone()


def recent_donations(limit=8, initiative_id=None):
    sql = """SELECT d.*, i.title AS initiative_title, i.slug AS initiative_slug
             FROM donations d JOIN initiatives i ON i.id = d.initiative_id
             WHERE d.status = 'confirmed' AND i.status != 'hidden'"""
    args = []
    if initiative_id:
        sql += " AND d.initiative_id = ?"
        args.append(initiative_id)
    sql += " ORDER BY d.created_at DESC, d.id DESC LIMIT ?"
    args.append(limit)
    return [dict(r) for r in get_db().execute(sql, args).fetchall()]


def list_donations(status=None, limit=500):
    sql = """SELECT d.*, i.title AS initiative_title
             FROM donations d JOIN initiatives i ON i.id = d.initiative_id"""
    args = []
    if status:
        sql += " WHERE d.status = ?"
        args.append(status)
    sql += " ORDER BY d.created_at DESC, d.id DESC LIMIT ?"
    args.append(limit)
    return [dict(r) for r in get_db().execute(sql, args).fetchall()]


def set_donation_status(donation_id, status):
    db = get_db()
    db.execute("UPDATE donations SET status = ? WHERE id = ?", (status, donation_id))
    db.commit()


# ---------------------------------------------------------------- التحديثات والمتطوعون
def list_updates(initiative_id):
    rows = get_db().execute(
        "SELECT * FROM updates WHERE initiative_id = ? ORDER BY created_at DESC, id DESC",
        (initiative_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def add_update(initiative_id, body):
    db = get_db()
    db.execute(
        "INSERT INTO updates (initiative_id, body, created_at) VALUES (?, ?, ?)",
        (initiative_id, body, iso(now())),
    )
    db.commit()


def add_volunteer(initiative_id, name, phone, email, note):
    db = get_db()
    db.execute(
        "INSERT INTO volunteers (initiative_id, name, phone, email, note, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (initiative_id, name, phone, email, note, iso(now())),
    )
    db.commit()


def list_volunteers():
    rows = get_db().execute(
        """SELECT v.*, i.title AS initiative_title
           FROM volunteers v LEFT JOIN initiatives i ON i.id = v.initiative_id
           ORDER BY v.created_at DESC, v.id DESC"""
    ).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------- الإحصاءات
def stats():
    db = get_db()
    raised, donations = db.execute(
        """SELECT COALESCE(SUM(d.amount), 0), COUNT(*)
           FROM donations d JOIN initiatives i ON i.id = d.initiative_id
           WHERE d.status = 'confirmed' AND i.status != 'hidden'"""
    ).fetchone()
    goal, active = db.execute(
        """SELECT COALESCE(SUM(goal), 0),
                  COALESCE(SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END), 0)
           FROM initiatives WHERE status != 'hidden'"""
    ).fetchone()
    volunteers = db.execute("SELECT COUNT(*) FROM volunteers").fetchone()[0]
    level = min(1.0, raised / goal) if goal else 0.0
    return {
        "raised": int(raised),
        "donations": int(donations),
        "goal": int(goal),
        "initiatives": int(active),
        "volunteers": int(volunteers),
        "level": round(level, 3),
        "pct": int(level * 100),
    }


def admin_overview():
    db = get_db()
    pending, pending_sum = db.execute(
        "SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM donations WHERE status = 'pending'"
    ).fetchone()
    return {"pending": int(pending), "pending_sum": int(pending_sum)}


def daily_totals(days=14):
    start = (now() - timedelta(days=days - 1)).date()
    rows = get_db().execute(
        """SELECT substr(created_at, 1, 10) AS day, SUM(amount) AS total
           FROM donations WHERE status = 'confirmed' AND substr(created_at, 1, 10) >= ?
           GROUP BY day""",
        (start.isoformat(),),
    ).fetchall()
    by_day = {r["day"]: int(r["total"]) for r in rows}
    out = []
    for n in range(days):
        day = start + timedelta(days=n)
        out.append({"day": day, "total": by_day.get(day.isoformat(), 0)})
    return out


# ---------------------------------------------------------------- بيانات تجريبية
_DEMO_INITIATIVES = [
    {
        "slug": "matbakh-elkhair", "category": "food", "urgent": 0, "target": 0.83, "goal": 90000,
        "title": "مطبخ الخير: وجبة ساخنة كل يوم",
        "summary": "نطهو ونوزّع وجبات ساخنة على كبار السن وعمال اليومية ومن لا مأوى لهم.",
        "location": "القاهرة الكبرى", "unit_label": "وجبة ساخنة", "unit_cost": 35,
        "story": "في الشتاء تصبح الوجبة الساخنة أكثر من طعام؛ هي لحظة دفء في يوم طويل.\n\n"
                 "يعمل المطبخ بفريق من المتطوعين يطهون ويعبّئون ويوزّعون الوجبات قبل المغرب في أماكن يعرفها الفريق جيدًا.\n\n"
                 "كل وجبة تُحسب بتكلفتها الفعلية، وما يزيد عن الهدف يُحوَّل إلى أيام تشغيل إضافية.",
        "updates": [(2, "وزّعنا أمس وجبات العشاء على ثلاثة مواقع، وبدأ متطوعون جدد العمل في التعبئة."),
                    (9, "انضم إلى الفريق طاهٍ متطوع ورفع طاقة المطبخ إلى ضعف ما كانت عليه.")],
    },
    {
        "slug": "qafila-tibbiya", "category": "health", "urgent": 0, "target": 0.71, "goal": 300000,
        "title": "قافلة طبية للقرى البعيدة",
        "summary": "كشف وعلاج وأدوية مجانية في قرى تبعد ساعات عن أقرب مستشفى.",
        "location": "مناطق نائية", "unit_label": "كشف وعلاج", "unit_cost": 100,
        "story": "كثير من الأسر تؤجّل الكشف حتى يصير المرض أصعب، لأن أقرب طبيب بعيد وتكلفة الطريق وحدها عبء.\n\n"
                 "تجمع القافلة أطباء متطوعين في مدرسة أو وحدة صحية ويُصرف الدواء في المكان نفسه.\n\n"
                 "التبرعات تغطي الأدوية والمستلزمات والنقل، بينما يتبرع الأطباء بوقتهم.",
        "updates": [(5, "اكتملت قافلة هذا الأسبوع، وجرى الكشف على مئات المرضى وصرف الأدوية في الموقع.")],
    },
    {
        "slug": "kafala-yateem", "category": "care", "urgent": 0, "target": 0.55, "goal": 200000,
        "title": "كفالة يتيم: رعاية شهرية ثابتة",
        "summary": "دعم شهري يغطي الغذاء والتعليم والعلاج لطفل فقد عائله.",
        "location": "محافظات مصر", "unit_label": "كفالة شهرية", "unit_cost": 300,
        "story": "الطفل يحتاج إلى استقرار قبل أي شيء، والكفالة الشهرية تمنح أسرته قدرة على التخطيط.\n\n"
                 "يُصرف الدعم على بنود واضحة: الغذاء والمصاريف الدراسية والعلاج، مع متابعة دورية من فريق المبادرة.\n\n"
                 "اختر كفالة شهر أو أكثر، وستصلك تحديثات عامة عن المبادرة هنا.",
        "updates": [(12, "بدأ العام الدراسي، وتم تسديد مصاريف المدارس لكل الأطفال المشمولين بالكفالة.")],
    },
    {
        "slug": "dafa-shita", "category": "winter", "urgent": 1, "target": 0.48, "goal": 120000,
        "title": "دفا الشتا: بطانية لكل محتاج",
        "summary": "بطاطين وملابس شتوية تصل إلى الأسر ودور الرعاية قبل أن تشتد البرودة.",
        "location": "القاهرة الكبرى", "unit_label": "بطانية شتوية", "unit_cost": 150,
        "story": "مع أول موجة برد تصبح البطانية احتياجًا عاجلًا لأسر تعيش في بيوت بلا تدفئة.\n\n"
                 "نشتري البطاطين بالجملة لنخفض التكلفة، ونوزّعها عبر متطوعين يعرفون الأسر في كل حي.\n\n"
                 "كل بطانية تصل إلى بيت قبل الليالي الباردة، والوقت هنا يصنع فرقًا.",
        "updates": [(1, "وصلت الدفعة الأولى من البطاطين، وبدأ التوزيع على الأسر المسجلة هذا الأسبوع.")],
    },
    {
        "slug": "sqya-qura", "category": "water", "urgent": 0, "target": 0.62, "goal": 250000,
        "title": "سقيا القرى: ماء نظيف لكل بيت",
        "summary": "نوصّل مياه الشرب النظيفة إلى بيوت لا تصلها الشبكة، بوصلات آمنة وفلاتر تدوم سنوات.",
        "location": "قرى الصعيد", "unit_label": "وصلة مياه لبيت", "unit_cost": 2500,
        "story": "في قرى كثيرة ما زالت الأسر تحمل الماء من مسافات بعيدة، وأحيانًا من مصادر غير صالحة للشرب.\n\n"
                 "تموّل هذه المبادرة وصلات منزلية وفلاتر لأسر لا تصلها الشبكة، مع صيانة دورية لمدة عامين.\n\n"
                 "كل وصلة تُوصّل الماء النظيف إلى بيت كامل، وتوفّر على الأم والأطفال ساعات يومية.",
        "updates": [(3, "تم تركيب أول اثنتي عشرة وصلة في القرية الأولى، ونعمل الآن على القرية الثانية."),
                    (14, "اعتُمدت قائمة الأسر المستفيدة بعد زيارات ميدانية.")],
    },
    {
        "slug": "shanta-madrasa", "category": "education", "urgent": 0, "target": 0.35, "goal": 180000,
        "title": "شنطة المدرسة: بداية عام بلا حرمان",
        "summary": "حقيبة وأدوات مدرسية كاملة لطفل لا تستطيع أسرته شراءها.",
        "location": "الدلتا", "unit_label": "حقيبة وأدوات", "unit_cost": 400,
        "story": "الطفل الذي يبدأ العام الدراسي بلا أدوات يشعر بالفرق من اليوم الأول.\n\n"
                 "تشمل الحقيبة كراسات وأقلامًا وزيًّا مدرسيًّا بحسب احتياج كل طفل، وتُسلَّم عبر المدارس.\n\n"
                 "تبرعك يمنحه بداية عادلة مع زملائه.",
        "updates": [],
    },
    {
        "slug": "sakan-karim", "category": "shelter", "urgent": 0, "target": 0.27, "goal": 400000,
        "title": "سكن كريم: ترميم بيوت الأسر المتعففة",
        "summary": "إصلاح السقف والجدران والأبواب كي تنام الأسرة في بيت آمن.",
        "location": "الصعيد والدلتا", "unit_label": "ترميم غرفة", "unit_cost": 5000,
        "story": "سقف يتسرّب منه المطر أو جدار متشقق قد يهدد أسرة كاملة.\n\n"
                 "يعاين مهندس متطوع كل بيت قبل الترميم، وتُنفَّذ الأعمال بأسعار التكلفة مع صنايعية من نفس المنطقة.\n\n"
                 "كل غرفة تُرمَّم تعني ليلة آمنة لأسرة.",
        "updates": [(20, "انتهت معاينة سبعة بيوت وجرى إعداد قوائم الأعمال المطلوبة.")],
    },
]

_FIRST = ["أحمد", "محمد", "منى", "سارة", "يوسف", "نور", "هدى", "كريم", "آية", "عمر", "ليلى", "مصطفى",
          "دعاء", "خالد", "رنا", "حسن", "فاطمة", "إبراهيم", "ياسمين", "طارق", "هبة", "عمرو", "سلمى",
          "باسم", "نهى", "شريف", "مريم", "أسامة", "إيمان", "وليد"]
_LAST = ["ع", "م", "ح", "س", "ي", "ف", "ن", "ك", "ر", "ص"]
_MESSAGES = ["جزاكم الله خيرًا", "اللهم تقبّل", "صدقة جارية عن والدي", "من القلب", "بالتوفيق للجميع",
             "ربنا يبارك في جهدكم", "لكم الأجر إن شاء الله"]
_AMOUNTS = [100, 150, 200, 250, 300, 500, 500, 1000, 1500, 2000, 3000]


def _seed_demo(conn):
    rng = random.Random(2026)
    base = now()
    for n, item in enumerate(_DEMO_INITIATIVES):
        created = base - timedelta(days=45 - n * 3)
        cur = conn.execute(
            """INSERT INTO initiatives
               (slug, title, summary, story, category, location, goal, unit_label, unit_cost, urgent, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)""",
            (item["slug"], item["title"], item["summary"], item["story"], item["category"], item["location"],
             item["goal"], item["unit_label"], item["unit_cost"], item["urgent"], iso(created)),
        )
        iid = cur.lastrowid
        total, target = 0, item["goal"] * item["target"]
        while total < target:
            if rng.random() < 0.45:
                amount = item["unit_cost"] * rng.choice([1, 2, 3, 5, 10])
            else:
                amount = rng.choice(_AMOUNTS)
            amount = min(amount, int(target - total) or amount)
            anonymous = rng.random() < 0.25
            name = "" if anonymous else f"{rng.choice(_FIRST)} {rng.choice(_LAST)}."
            when = base - timedelta(minutes=rng.randint(20, 30 * 24 * 60))
            conn.execute(
                """INSERT INTO donations
                   (initiative_id, donor_name, amount, message, anonymous, method, status, reference, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, 'confirmed', ?, ?)""",
                (iid, name, amount, rng.choice(_MESSAGES) if rng.random() < 0.4 else "", int(anonymous),
                 rng.choice(["wallet", "instapay", "card"]), "SB-" + secrets.token_hex(4).upper(), iso(when)),
            )
            total += amount
        for days_ago, body in item["updates"]:
            conn.execute(
                "INSERT INTO updates (initiative_id, body, created_at) VALUES (?, ?, ?)",
                (iid, body, iso(base - timedelta(days=days_ago))),
            )
    for name, phone, note in [("هدير ا.", "01000000001", "أستطيع المساعدة في التعبئة والتوزيع أيام الجمعة."),
                              ("كريم ن.", "01000000002", "مهندس مدني، أستطيع معاينة بيوت الترميم."),
                              ("سلمى ع.", "01000000003", "معلمة، أحب المشاركة في مبادرات التعليم.")]:
        conn.execute(
            "INSERT INTO volunteers (initiative_id, name, phone, email, note, created_at) VALUES (NULL, ?, ?, '', ?, ?)",
            (name, phone, note, iso(base - timedelta(days=rng.randint(1, 20)))),
        )
