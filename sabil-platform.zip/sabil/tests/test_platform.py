"""اختبار شامل للمنصة عبر Flask test client (قاعدة بيانات مؤقتة)."""
import os
import re
import sys
import tempfile

tmp = tempfile.mkdtemp()
os.environ["DATABASE"] = os.path.join(tmp, "t.db")
os.environ["ADMIN_PASSWORD"] = "test-pass-123"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as appmod  # noqa: E402
from app import create_app  # noqa: E402

app = create_app()
c = app.test_client()
ok = fail = 0


def check(name, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print("  ok  ", name)
    else:
        fail += 1
        print("  FAIL", name, extra)


def token(client=c, path="/"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)


print("== الصفحات العامة")
for path in ["/", "/initiatives", "/initiatives?cat=water", "/initiatives?q=سقيا", "/i/dafa-shita",
             "/volunteer", "/about", "/healthz", "/api/stats", "/api/initiatives", "/api/initiatives/dafa-shita"]:
    r = c.get(path)
    check(f"GET {path} -> 200", r.status_code == 200, r.status_code)
check("404 للمبادرة غير الموجودة", c.get("/i/nope").status_code == 404)
home = c.get("/").get_data(as_text=True)
check("الصفحة الرئيسية تعرض القلّة والبطاقات", "jar__water" in home and home.count("vessel__arch") >= 6)
check("أرقام عربية-هندية", re.search(r"[٠-٩]{2}", home) is not None)
check("شريط النسخة التجريبية", "نسخة تجريبية" in home)
check("رأس CSP", "script-src 'self'" in c.get("/").headers["Content-Security-Policy"])
check("لا سكربت مضمّن", not re.search(r"<script(?![^>]*src=)[^>]*>", home))
check("بحث لا يرجع شيئًا يعطي رسالة", "لا توجد مبادرات مطابقة" in c.get("/initiatives?q=zzzz").get_data(as_text=True))

print("== التبرع عبر الـ API")
s0 = c.get("/api/stats").get_json()
i0 = c.get("/api/initiatives/dafa-shita").get_json()
tk = token(c, "/i/dafa-shita")
H = {"X-CSRF-Token": tk}
r = c.post("/api/initiatives/dafa-shita/donate", json={"amount": 300, "donor_name": "اختبار", "method": "wallet"})
check("بدون CSRF يُرفض", r.status_code == 400)
r = c.post("/api/initiatives/dafa-shita/donate", json={"amount": 300, "donor_name": "اختبار", "method": "wallet", "message": "جزاكم الله خيرًا"}, headers=H)
out = r.get_json()
check("تبرع صحيح 201", r.status_code == 201 and out["ok"], out)
check("المرجع بصيغة SB-", out["reference"].startswith("SB-"))
check("المبلغ زاد في المبادرة", out["initiative"]["raised"] == i0["raised"] + 300)
check("إجمالي المنصة زاد", out["totals"]["raised"] == s0["raised"] + 300)
r = c.post("/api/initiatives/dafa-shita/donate", json={"amount": "٢٥٠", "anonymous": True}, headers=H)
check("أرقام عربية-هندية + فاعل خير", r.status_code == 201 and r.get_json()["donor"] == "فاعل خير", r.get_json())
for bad, label in [({"amount": 5, "donor_name": "أ"}, "أقل من الحد"), ({"amount": "abc", "donor_name": "أ"}, "ليس رقمًا"),
                   ({"amount": 100}, "بلا اسم"), ({"amount": 9999999, "donor_name": "أ"}, "فوق الحد"),
                   ({"amount": 100, "donor_name": "أ", "website": "spam"}, "حقل الفخ")]:
    r = c.post("/api/initiatives/dafa-shita/donate", json=bad, headers=H)
    check(f"رفض: {label}", r.status_code == 400 and not r.get_json()["ok"], r.get_json())
r = c.post("/api/initiatives/nope/donate", json={"amount": 100, "donor_name": "أ"}, headers=H)
check("مبادرة غير موجودة 404", r.status_code == 404)
r = c.post("/api/initiatives/dafa-shita/donate", data="not json", headers=H)
check("جسم غير JSON 400", r.status_code == 400)
page = c.get("/i/dafa-shita").get_data(as_text=True)
check("المتبرع يظهر في الصفحة", "اختبار" in page and "جزاكم الله خيرًا" in page)

print("== التبرع عبر النموذج (بلا JS)")
r = c.post("/i/dafa-shita/donate", data={"csrf_token": tk, "amount": "150", "donor_name": "نموذج", "method": "card"})
check("تحويل بعد النجاح", r.status_code == 302 and "thanks=SB-" in r.headers["Location"], r.headers.get("Location"))
page = c.get(r.headers["Location"]).get_data(as_text=True)
check("رسالة الشكر والمرجع", "شكرًا لك" in page and "SB-" in page)
r = c.post("/i/dafa-shita/donate", data={"csrf_token": tk, "amount": "1", "donor_name": "x"}, follow_redirects=True)
check("خطأ يظهر كرسالة", "أقل مبلغ للتبرع" in r.get_data(as_text=True))

print("== حد الطلبات")
c2 = app.test_client()
t2 = token(c2)
codes = [c2.post("/api/initiatives/dafa-shita/donate", json={"amount": 50, "donor_name": "س"}, headers={"X-CSRF-Token": t2}).status_code for _ in range(12)]
check("429 بعد تجاوز الحد", 429 in codes, codes)

print("== المتطوعون")
c3 = app.test_client()
t3 = token(c3, "/volunteer")
r = c3.post("/volunteer", data={"csrf_token": t3, "name": "متطوع", "phone": "01012345678", "i": "dafa-shita", "note": "جاهز"}, follow_redirects=True)
check("تسجيل متطوع", "وصلنا طلبك" in r.get_data(as_text=True))
r = c3.post("/volunteer", data={"csrf_token": t3, "name": "متطوع", "phone": "12"}, follow_redirects=True)
check("هاتف خاطئ يُرفض", "رقم الهاتف غير صحيح" in r.get_data(as_text=True))

print("== الإدارة")
a = app.test_client()
r = a.get("/admin")
check("/admin يحول لتسجيل الدخول", r.status_code == 302 and "/admin/login" in r.headers["Location"])
ta = token(a, "/admin/login")
r = a.post("/admin/login", data={"csrf_token": ta, "username": "admin", "password": "wrong"})
check("كلمة مرور خاطئة", "غير صحيحة" in r.get_data(as_text=True))
r = a.post("/admin/login?next=//evil.com", data={"csrf_token": ta, "username": "admin", "password": "test-pass-123"})
check("دخول ناجح ولا تحويل خارجي", r.status_code == 302 and r.headers["Location"].endswith("/admin"), r.headers.get("Location"))
for path in ["/admin", "/admin/initiatives", "/admin/initiatives/new", "/admin/initiatives/1/edit", "/admin/donations",
             "/admin/donations?status=pending", "/admin/volunteers"]:
    check(f"GET {path} -> 200", a.get(path).status_code == 200)
csvr = a.get("/admin/donations.csv")
check("تصدير CSV", csvr.status_code == 200 and "SB-" in csvr.get_data(as_text=True))
ta = token(a, "/admin/initiatives/new")
bad = a.post("/admin/initiatives/new", data={"csrf_token": ta, "title": "", "goal": "5"})
check("نموذج غير صالح يعيد الصفحة بأخطاء", "العنوان مطلوب" in bad.get_data(as_text=True))
r = a.post("/admin/initiatives/new", data={"csrf_token": ta, "title": "مبادرة اختبار", "summary": "وصف", "story": "قصة\n\nفقرة ثانية",
                                           "category": "food", "goal": "1000", "unit_cost": "50", "unit_label": "وجبة", "status": "active",
                                           "slug": "test-init"})
check("إضافة مبادرة", r.status_code == 302)
check("تظهر في الموقع", c.get("/i/test-init").status_code == 200)
r = a.post("/admin/initiatives/new", data={"csrf_token": ta, "title": "x", "summary": "y", "category": "food", "goal": "1000", "slug": "test-init"})
check("معرّف مكرر يُرفض", "مستخدم" in r.get_data(as_text=True))
r = a.post("/admin/initiatives/new", data={"csrf_token": ta, "title": "x", "summary": "y", "category": "food", "goal": "1000", "cover_url": "javascript:alert(1)"})
check("رابط صورة خطير يُرفض", "http" in r.get_data(as_text=True) and "javascript" not in a.get("/admin/initiatives").get_data(as_text=True))
new_id = int(re.search(r"/admin/initiatives/(\d+)/edit", a.get("/admin/initiatives").get_data(as_text=True)).group(0).split("/")[3])
items = a.get("/admin/initiatives").get_data(as_text=True)
tid = [int(x) for x in re.findall(r'/admin/initiatives/(\d+)/edit">مبادرة اختبار', items)][0]
r = a.post(f"/admin/initiatives/{tid}/updates", data={"csrf_token": ta, "body": "تحديث تجريبي"})
check("نشر تحديث", r.status_code == 302 and "تحديث تجريبي" in c.get("/i/test-init").get_data(as_text=True))
r = a.post(f"/admin/initiatives/{tid}/edit", data={"csrf_token": ta, "title": "مبادرة اختبار", "summary": "وصف", "category": "food", "goal": "1000", "slug": "test-init", "status": "completed"})
check("تعديل الحالة إلى مكتملة", r.status_code == 302 and "اكتملت هذه المبادرة" in c.get("/i/test-init").get_data(as_text=True))
appmod._hits.clear()
r = c.post("/api/initiatives/test-init/donate", json={"amount": 100, "donor_name": "أ"}, headers=H)
check("لا تبرع لمبادرة مكتملة", r.status_code == 409)
r = a.post(f"/admin/initiatives/{tid}/edit", data={"csrf_token": ta, "title": "مبادرة اختبار", "summary": "وصف", "category": "food", "goal": "1000", "slug": "test-init", "status": "hidden"})
check("المخفية 404 للعامة", c.get("/i/test-init").status_code == 404)
r = a.post(f"/admin/initiatives/{tid}/delete", data={"csrf_token": ta})
check("حذف مبادرة", r.status_code == 302 and c.get("/i/test-init").status_code == 404)
r = a.post("/admin/logout", data={"csrf_token": ta})
check("خروج ثم منع الوصول", a.get("/admin").status_code == 302)

appmod._hits.clear()
print("== وضع التأكيد اليدوي (manual)")
os.environ["PAYMENT_PROVIDER"] = "manual"
os.environ["DATABASE"] = os.path.join(tmp, "m.db")
os.environ["PAYMENT_INSTRUCTIONS"] = "حوّل المبلغ إلى المحفظة المعلنة وأرسل الرقم المرجعي."
m = create_app()
mc = m.test_client()
tm = token(mc, "/i/dafa-shita")
s_before = mc.get("/api/stats").get_json()["raised"]
r = mc.post("/api/initiatives/dafa-shita/donate", json={"amount": 500, "donor_name": "يدوي"}, headers={"X-CSRF-Token": tm})
check("التبرع بانتظار التأكيد", r.get_json()["status"] == "pending")
check("لا يُحسب قبل التأكيد", mc.get("/api/stats").get_json()["raised"] == s_before)
check("لا شريط تجريبي في وضع manual", "نسخة تجريبية: التبرعات" not in mc.get("/").get_data(as_text=True))
ma = m.test_client()
ta = token(ma, "/admin/login")
ma.post("/admin/login", data={"csrf_token": ta, "username": "admin", "password": "test-pass-123"})
ta = token(ma, "/admin/donations")
page = ma.get("/admin/donations?status=pending").get_data(as_text=True)
did = int(re.search(r"/admin/donations/(\d+)/status", page).group(1))
ma.post(f"/admin/donations/{did}/status", data={"csrf_token": ta, "status": "confirmed"})
check("بعد التأكيد يُحسب", mc.get("/api/stats").get_json()["raised"] == s_before + 500)

print(f"\n{ok} نجح، {fail} فشل")
sys.exit(1 if fail else 0)
