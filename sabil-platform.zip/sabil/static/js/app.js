(() => {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const nf = new Intl.NumberFormat("ar-EG");
  const nf1 = new Intl.NumberFormat("ar-EG", { maximumFractionDigits: 1 });
  const fmt = {
    int: (v) => nf.format(Math.round(v)),
    money: (v) => nf.format(Math.round(v)) + " ج.م",
    compact: (v) => {
      v = Math.round(v);
      if (v >= 1e6) return nf1.format(v / 1e6) + " مليون";
      if (v >= 1e3) return nf1.format(v / 1e3) + " ألف";
      return nf.format(v);
    },
  };
  const bind = (name, value) =>
    $$(`[data-bind="${name}"]`).forEach((el) => (el.textContent = (fmt[el.dataset.fmt] || fmt.int)(value)));
  const csrf = () => ($('meta[name="csrf-token"]') || {}).content || "";

  function toast(text) {
    const el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    el.textContent = text;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }

  /* تأكيد الحذف في الإدارة */
  $$("form[data-confirm]").forEach((f) =>
    f.addEventListener("submit", (e) => {
      if (!window.confirm(f.dataset.confirm)) e.preventDefault();
    })
  );

  /* مشاركة المبادرة */
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-share]");
    if (!btn) return;
    const data = { title: btn.dataset.title || document.title, url: location.href.split("#")[0].split("?")[0] };
    try {
      if (navigator.share) await navigator.share(data);
      else {
        await navigator.clipboard.writeText(data.url);
        toast("تم نسخ الرابط");
      }
    } catch (_) {
      /* أغلق المستخدم نافذة المشاركة */
    }
  });

  /* بعد التحويل من نموذج بلا جافاسكربت: ركّز على رسالة الشكر */
  const serverThanks = $(".donate .thanks");
  if (serverThanks && location.hash === "#donate") serverThanks.focus({ preventScroll: true });

  /* نموذج التبرع */
  const form = $("[data-donate-form]");
  if (!form) return;

  const panel = $("[data-donate-panel]");
  const amountInput = form.elements.amount;
  const nameInput = form.elements.donor_name;
  const anonInput = form.elements.anonymous;
  const chips = $$(".chip", form);
  const impact = $("[data-impact]", form);
  const submit = $("[data-submit]", form);
  const errorEl = $("[data-error]", form);
  const unitCost = parseInt(form.dataset.unitCost, 10) || 0;
  const unitLabel = form.dataset.unitLabel || "";
  const defaultAmount = amountInput.value;

  const readAmount = () => {
    const digits = String(amountInput.value).replace(/\D/g, "");
    return digits ? parseInt(digits, 10) : 0;
  };

  function refresh() {
    const a = readAmount();
    chips.forEach((c) => c.classList.toggle("is-on", parseInt(c.dataset.amount, 10) === a));
    submit.textContent = a >= 10 ? `تأكيد التبرع بمبلغ ${fmt.money(a)}` : "تأكيد التبرع";
    if (unitCost && unitLabel && a >= 10) {
      const n = Math.floor(a / unitCost);
      impact.textContent =
        n >= 1
          ? `يعادل ${nf.format(n)} × ${unitLabel}`
          : `يساهم في تكلفة «${unitLabel}» (${fmt.money(unitCost)})`;
    } else {
      impact.textContent = "";
    }
  }

  chips.forEach((c) =>
    c.addEventListener("click", () => {
      amountInput.value = c.dataset.amount;
      refresh();
    })
  );
  amountInput.addEventListener("input", refresh);
  anonInput.addEventListener("change", () => {
    nameInput.disabled = anonInput.checked;
    if (anonInput.checked) nameInput.value = "";
  });
  refresh();

  function addDonorRow(out) {
    const list = $("#donors-list");
    if (!list) return;
    const li = document.createElement("li");
    const who = document.createElement("span");
    who.className = "donors__who";
    who.textContent = out.donor;
    const amt = document.createElement("span");
    amt.className = "donors__amt";
    amt.textContent = fmt.money(out.amount);
    const time = document.createElement("time");
    time.className = "donors__time";
    time.textContent = "الآن";
    li.append(who, amt, time);
    if (out.message) {
      const q = document.createElement("q");
      q.className = "donors__msg";
      q.textContent = out.message;
      li.append(q);
    }
    $$("li.empty", list).forEach((n) => n.remove());
    list.prepend(li);
    while (list.children.length > 10) list.lastElementChild.remove();
  }

  function showThanks(out) {
    const original = [...panel.childNodes];
    const frag = $("#thanks-tpl").content.cloneNode(true);
    const set = (key, text) => $$(`[data-t="${key}"]`, frag).forEach((el) => (el.textContent = text));
    set("name", out.donor && out.donor !== "فاعل خير" ? out.donor : "");
    set("amount", fmt.money(out.amount));
    set("ref", out.reference);
    const pending = out.status === "pending";
    $$('[data-t="pending"], [data-t="how"]', frag).forEach((el) => (el.hidden = !pending));
    $$('[data-t="done"]', frag).forEach((el) => (el.hidden = pending));
    panel.replaceChildren(frag);
    const box = $(".thanks", panel);
    box.focus();
    $("[data-again]", panel).addEventListener("click", () => {
      panel.replaceChildren(...original);
      amountInput.value = defaultAmount;
      submit.disabled = false;
      errorEl.hidden = true;
      refresh();
      amountInput.focus();
    });
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorEl.hidden = true;
    submit.disabled = true;
    submit.textContent = "جارٍ تسجيل التبرع…";
    const body = Object.fromEntries(new FormData(form));
    delete body.csrf_token;
    try {
      const res = await fetch(form.dataset.api, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", "X-CSRF-Token": csrf() },
        body: JSON.stringify(body),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok || !out.ok) throw new Error(out.error || "تعذّر إتمام التبرع. حاول مرة أخرى.");
      const init = out.initiative;
      bind("raised", init.raised);
      bind("pct", init.pct);
      bind("donors", init.donors);
      const level = Math.min(1, init.raised / init.goal);
      $$("[data-jar]").forEach((j) => j.style.setProperty("--lvl", level));
      addDonorRow(out);
      showThanks(out);
    } catch (err) {
      errorEl.textContent = err.message || "تعذّر إتمام التبرع. حاول مرة أخرى.";
      errorEl.hidden = false;
      submit.disabled = false;
      refresh();
    }
  });
})();
