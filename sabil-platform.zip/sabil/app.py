"""سبيل: منصة تبرعات ومبادرات خيرية (Flask + SQLite).

التشغيل:  python app.py        ثم افتح  http://127.0.0.1:5000
الإدارة:  http://127.0.0.1:5000/admin
"""
import csv
import io
import os
import re
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from functools import wraps
from urllib.parse import urlparse

import click
from flask import (Flask, Response, abort, current_app, flash, jsonify, redirect,
                   render_template, request, session, url_for)
from werkzeug.security import check_password_hash

import db as database
from catalog import CATEGORIES, PAYMENT_METHODS
from payments import get_provider

try:
    from zoneinfo import ZoneInfo

    CAIRO = ZoneInfo("Africa/Cairo")
except Exception:  # لو حزمة المناطق الزمنية غير متوفرة
    CAIRO = timezone(timedelta(hours=2))

_TO_AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")
_FROM_AR = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫٬", "01234567890123456789.,")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{2,59}$")


class DonationError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


# ------------------------------------------------------------------ أدوات عامة
def _load_secret(instance_path):
    env = os.getenv("SECRET_KEY")
    if env:
        return env
    path = os.path.join(instance_path, "secret_key")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    key = secrets.token_hex(32)
    with open(path, "w", encoding="utf-8") as f:
        f.write(key)
    os.chmod(path, 0o600)
    return key


_hits = defaultdict(deque)


def rate_ok(key, limit, window):
    """حد بسيط للطلبات لكل عنوان IP (في الذاكرة؛ لعدة عمليات استخدم Redis)."""
    t = time.monotonic()
    q = _hits[key]
    while q and t - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        return False
    q.append(t)
    return True


def clean(text, limit, multiline=False):
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(text or "")).strip()
    if not multiline:
        text = re.sub(r"\s+", " ", text)
    return text[:limit]


def parse_int(value):
    s = re.sub(r"[,\s]", "", str(value or "").translate(_FROM_AR))
    if not re.fullmatch(r"\d{1,9}", s):
        raise ValueError
    return int(s)


def safe_cover(url):
    url = (url or "").strip()
    if not url:
        return ""
    p = urlparse(url)
    return url if p.scheme in ("http", "https") and p.netloc else None


def amount_chips(i):
    unit = i["unit_cost"]
    if unit and unit <= 5000:
        return [unit, unit * 2, unit * 5, unit * 10]
    return [50, 100, 250, 500]


# ------------------------------------------------------------------ الفلاتر
def ar_num(value):
    try:
        n = int(value)
    except (TypeError, ValueError):
        return str(value).translate(_TO_AR)
    return f"{n:,}".replace(",", "٬").translate(_TO_AR)


def money(value):
    return ar_num(value) + " ج.م"


def compact(value):
    v = int(value or 0)
    if v >= 1_000_000:
        n, unit = v / 1_000_000, "مليون"
    elif v >= 1000:
        n, unit = v / 1000, "ألف"
    else:
        return ar_num(v)
    s = f"{n:.1f}".rstrip("0").rstrip(".")
    return s.replace(".", "٫").translate(_TO_AR) + " " + unit


def _parse(value):
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(str(value))


def fmt_date(value, with_time=False):
    dt = _parse(value).astimezone(CAIRO)
    s = dt.strftime("%d/%m/%Y %H:%M" if with_time else "%d/%m/%Y")
    return s.translate(_TO_AR)


def _plural(n, one, two, few, many):
    if n == 1:
        return one
    if n == 2:
        return two
    return f"{ar_num(n)} {few if 3 <= n <= 10 else many}"


def time_ago(value):
    seconds = max(0, int((datetime.now(timezone.utc) - _parse(value)).total_seconds()))
    if seconds < 60:
        return "الآن"
    mins = seconds // 60
    if mins < 60:
        return "منذ " + _plural(mins, "دقيقة", "دقيقتين", "دقائق", "دقيقة")
    hours = mins // 60
    if hours < 24:
        return "منذ " + _plural(hours, "ساعة", "ساعتين", "ساعات", "ساعة")
    days = hours // 24
    if days < 30:
        return "منذ " + _plural(days, "يوم", "يومين", "أيام", "يومًا")
    return fmt_date(value)


def paragraphs(text):
    return [p.strip() for p in re.split(r"\n\s*\n", text or "") if p.strip()]


def donor_label(d):
    return "فاعل خير" if d["anonymous"] or not d["donor_name"] else d["donor_name"]


# ------------------------------------------------------------------ التبرع (مشترك بين الـ API والنموذج)
def process_donation(slug, data):
    ip = request.remote_addr or "?"
    if not rate_ok(f"donate:{ip}", 10, 600):
        raise DonationError("محاولات كثيرة في وقت قصير. انتظر قليلًا ثم حاول مرة أخرى.", 429)
    if data.get("website"):  # حقل فخ للروبوتات
        raise DonationError("تعذّر إتمام الطلب.", 400)

    initiative = database.get_initiative(slug)
    if not initiative:
        raise DonationError("هذه المبادرة غير موجودة.", 404)
    if initiative["status"] != "active":
        raise DonationError("هذه المبادرة مكتملة ولا تستقبل تبرعات جديدة.", 409)

    try:
        amount = parse_int(data.get("amount"))
    except ValueError:
        raise DonationError("اكتب المبلغ بالأرقام، مثل ١٠٠.")
    low, high = current_app.config["MIN_DONATION"], current_app.config["MAX_DONATION"]
    if amount < low:
        raise DonationError(f"أقل مبلغ للتبرع {ar_num(low)} ج.م.")
    if amount > high:
        raise DonationError(f"للتبرعات التي تتجاوز {ar_num(high)} ج.م تواصل معنا مباشرة.")

    anonymous = str(data.get("anonymous", "")).lower() in ("1", "true", "on", "yes")
    name = clean(data.get("donor_name"), 40)
    if not name and not anonymous:
        raise DonationError("اكتب اسمك، أو اختر التبرع باسم «فاعل خير».")
    method = data.get("method") if data.get("method") in PAYMENT_METHODS else "wallet"
    message = clean(data.get("message"), 200)

    provider = get_provider(current_app.config["PAYMENT_PROVIDER"])
    result = provider.charge(amount=amount, method=method, donor_name=name,
                             initiative_title=initiative["title"])
    if not result.ok:
        raise DonationError(result.message or "تعذّرت عملية الدفع. حاول مرة أخرى.", 402)

    database.add_donation(initiative["id"], "" if anonymous else name, amount, message,
                          anonymous, method, result.status, result.reference)
    fresh = database.get_initiative(slug)
    return {
        "reference": result.reference,
        "status": result.status,
        "amount": amount,
        "donor": "فاعل خير" if anonymous else name,
        "message": message,
        "initiative": {"raised": fresh["raised"], "goal": fresh["goal"],
                       "pct": fresh["pct"], "donors": fresh["donors"]},
        "totals": database.stats(),
    }


def public_initiative(i):
    cat = CATEGORIES.get(i["category"], CATEGORIES["care"])
    return {
        "slug": i["slug"], "title": i["title"], "summary": i["summary"],
        "category": i["category"], "category_label": cat["label"], "location": i["location"],
        "goal": i["goal"], "raised": i["raised"], "donors": i["donors"], "pct": i["pct"],
        "unit_label": i["unit_label"], "unit_cost": i["unit_cost"],
        "urgent": bool(i["urgent"]), "status": i["status"],
        "url": url_for("initiative", slug=i["slug"], _external=True),
    }


# ------------------------------------------------------------------ المصنع
def create_app():
    app = Flask(__name__, instance_relative_config=True)
    os.makedirs(app.instance_path, exist_ok=True)
    app.config.update(
        SITE_NAME=os.getenv("SITE_NAME", "سبيل"),
        DATABASE=os.getenv("DATABASE", os.path.join(app.instance_path, "sabil.db")),
        SECRET_KEY=_load_secret(app.instance_path),
        PAYMENT_PROVIDER=os.getenv("PAYMENT_PROVIDER", "demo"),
        PAYMENT_INSTRUCTIONS=os.getenv("PAYMENT_INSTRUCTIONS", ""),
        SEED_DEMO=os.getenv("SEED_DEMO", "1") == "1",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=64 * 1024,
        MIN_DONATION=10,
        MAX_DONATION=500_000,
        JSON_AS_ASCII=False,
    )
    app.json.ensure_ascii = False
    app.teardown_appcontext(database.close_db)
    with app.app_context():
        database.init_db()

    def csrf_token():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(24)
        return session["csrf"]

    app.jinja_env.globals.update(csrf_token=csrf_token, CATEGORIES=CATEGORIES,
                                 PAYMENT_METHODS=PAYMENT_METHODS, donor_label=donor_label)
    app.jinja_env.filters.update(ar_num=ar_num, money=money, compact=compact, time_ago=time_ago,
                                 fmt_date=fmt_date, paragraphs=paragraphs)

    @app.context_processor
    def inject():
        return {
            "site_name": current_app.config["SITE_NAME"],
            "is_demo": current_app.config["PAYMENT_PROVIDER"] == "demo",
            "year": datetime.now(CAIRO).year,
        }

    # ---------------------------------------------------------- الحماية
    @app.before_request
    def protect():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token", "")
            expected = session.get("csrf", "")
            if not sent or not expected or not secrets.compare_digest(sent.encode(), expected.encode()):
                if request.path.startswith("/api/"):
                    return jsonify(ok=False, error="انتهت صلاحية الصفحة. حدّثها ثم حاول مرة أخرى."), 400
                abort(400)

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: https:; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src https://fonts.gstatic.com; script-src 'self'; "
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        )
        if request.path.startswith("/admin") or request.path.startswith("/api"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def admin_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("admin_id") or not database.get_admin_by_id(session["admin_id"]):
                session.pop("admin_id", None)
                return redirect(url_for("admin_login", next=request.full_path.rstrip("?")))
            return view(*args, **kwargs)

        return wrapped

    # ---------------------------------------------------------- الصفحات العامة
    @app.get("/")
    def home():
        items = database.list_initiatives()
        active = [i for i in items if i["status"] == "active"]
        return render_template("home.html", featured=active[:6], stats=database.stats(),
                               recent=database.recent_donations(8))

    @app.get("/initiatives")
    def initiatives():
        cat = request.args.get("cat", "")
        q = clean(request.args.get("q"), 60)
        if cat not in CATEGORIES:
            cat = ""
        return render_template("initiatives.html", items=database.list_initiatives(cat or None, q or None),
                               cat=cat, q=q)

    @app.get("/i/<slug>")
    def initiative(slug):
        i = database.get_initiative(slug)
        if not i:
            abort(404)
        thanks = None
        ref = request.args.get("thanks", "")
        if ref:
            row = database.get_donation_by_reference(ref)
            if row and row["initiative_id"] == i["id"]:
                thanks = {"reference": row["reference"], "amount": row["amount"], "status": row["status"]}
        return render_template("initiative.html", i=i, chips=amount_chips(i), thanks=thanks,
                               updates=database.list_updates(i["id"]),
                               donors=database.recent_donations(10, i["id"]),
                               stats=database.stats(),
                               instructions=current_app.config["PAYMENT_INSTRUCTIONS"])

    @app.post("/i/<slug>/donate")
    def donate_form(slug):
        try:
            result = process_donation(slug, request.form)
        except DonationError as e:
            if e.status == 404:
                abort(404)
            flash(e.message, "error")
            return redirect(url_for("initiative", slug=slug, _anchor="donate"))
        return redirect(url_for("initiative", slug=slug, thanks=result["reference"], _anchor="donate"))

    @app.route("/volunteer", methods=["GET", "POST"])
    def volunteer():
        items = [i for i in database.list_initiatives() if i["status"] == "active"]
        selected = request.values.get("i", "")
        form = {}
        if request.method == "POST":
            form = request.form
            if form.get("website"):
                abort(400)
            if not rate_ok(f"vol:{request.remote_addr}", 5, 3600):
                flash("محاولات كثيرة. حاول بعد قليل.", "error")
            else:
                name, phone = clean(form.get("name"), 60), clean(form.get("phone"), 20).translate(_FROM_AR)
                email = clean(form.get("email"), 80)
                note = clean(form.get("note"), 400)
                target = next((i for i in items if i["slug"] == selected), None)
                if not name:
                    flash("اكتب اسمك حتى نعرف بمن نتواصل.", "error")
                elif not re.fullmatch(r"\+?\d[\d\s-]{7,16}", phone):
                    flash("رقم الهاتف غير صحيح. اكتبه بالأرقام، مثل ٠١٠٠٠٠٠٠٠٠٠.", "error")
                elif email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
                    flash("البريد الإلكتروني غير صحيح. يمكنك تركه فارغًا.", "error")
                else:
                    database.add_volunteer(target["id"] if target else None, name, phone, email, note)
                    flash("وصلنا طلبك. سنتواصل معك قريبًا، وشكرًا لوقتك.", "ok")
                    return redirect(url_for("volunteer"))
        return render_template("volunteer.html", items=items, selected=selected, form=form)

    @app.get("/about")
    def about():
        return render_template("about.html", stats=database.stats())

    @app.get("/healthz")
    def healthz():
        return {"ok": True}

    # ---------------------------------------------------------- الـ API العام
    @app.get("/api/stats")
    def api_stats():
        return jsonify(database.stats())

    @app.get("/api/initiatives")
    def api_initiatives():
        cat = request.args.get("cat") if request.args.get("cat") in CATEGORIES else None
        return jsonify([public_initiative(i) for i in database.list_initiatives(cat)])

    @app.get("/api/initiatives/<slug>")
    def api_initiative(slug):
        i = database.get_initiative(slug)
        if not i:
            return jsonify(ok=False, error="المبادرة غير موجودة."), 404
        return jsonify(public_initiative(i))

    @app.post("/api/initiatives/<slug>/donate")
    def api_donate(slug):
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(ok=False, error="صيغة الطلب غير صحيحة."), 400
        try:
            result = process_donation(slug, data)
        except DonationError as e:
            return jsonify(ok=False, error=e.message), e.status
        return jsonify(ok=True, **result), 201

    # ---------------------------------------------------------- الإدارة
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            if not rate_ok(f"login:{request.remote_addr}", 8, 600):
                flash("محاولات كثيرة. انتظر عشر دقائق ثم حاول مرة أخرى.", "error")
            else:
                admin = database.get_admin(clean(request.form.get("username"), 40))
                if admin and check_password_hash(admin["password_hash"], request.form.get("password", "")):
                    session.clear()
                    session["admin_id"] = admin["id"]
                    session.permanent = True
                    nxt = request.args.get("next", "")
                    return redirect(nxt if nxt.startswith("/admin") and not nxt.startswith("//") else url_for("admin_home"))
                flash("اسم المستخدم أو كلمة المرور غير صحيحة.", "error")
        return render_template("admin/login.html")

    @app.post("/admin/logout")
    def admin_logout():
        session.clear()
        return redirect(url_for("home"))

    @app.get("/admin")
    @admin_required
    def admin_home():
        daily = database.daily_totals(14)
        peak = max([d["total"] for d in daily] + [1])
        for d in daily:
            d["h"] = max(2, int(d["total"] * 100 / peak)) if d["total"] else 2
        return render_template("admin/dashboard.html", stats=database.stats(), over=database.admin_overview(),
                               daily=daily, items=database.list_initiatives(include_hidden=True),
                               recent=database.list_donations(limit=8))

    @app.get("/admin/initiatives")
    @admin_required
    def admin_initiatives():
        return render_template("admin/initiatives.html", items=database.list_initiatives(include_hidden=True))

    def parse_initiative_form(form, current_id=None):
        errors, data = [], {}
        data["title"] = clean(form.get("title"), 90)
        data["summary"] = clean(form.get("summary"), 220)
        data["story"] = clean(form.get("story"), 4000, multiline=True)
        data["category"] = form.get("category") if form.get("category") in CATEGORIES else ""
        data["location"] = clean(form.get("location"), 60)
        data["unit_label"] = clean(form.get("unit_label"), 40)
        data["urgent"] = 1 if form.get("urgent") else 0
        data["status"] = form.get("status") if form.get("status") in ("active", "completed", "hidden") else "active"
        if not data["title"]:
            errors.append("العنوان مطلوب.")
        if not data["summary"]:
            errors.append("اكتب وصفًا قصيرًا للمبادرة.")
        if not data["category"]:
            errors.append("اختر تصنيف المبادرة.")
        try:
            data["goal"] = parse_int(form.get("goal"))
            if data["goal"] < 100:
                raise ValueError
        except ValueError:
            data["goal"] = 0
            errors.append("الهدف المالي يجب أن يكون رقمًا لا يقل عن ١٠٠ ج.م.")
        try:
            data["unit_cost"] = parse_int(form.get("unit_cost") or "0")
        except ValueError:
            data["unit_cost"] = 0
            errors.append("تكلفة الوحدة رقم صحيح (أو صفر).")
        cover = safe_cover(form.get("cover_url"))
        if cover is None:
            errors.append("رابط الصورة يجب أن يبدأ بـ http أو https.")
            cover = ""
        data["cover_url"] = cover
        slug = clean(form.get("slug"), 60).lower()
        if not slug:
            slug = "init-" + secrets.token_hex(3)
        if not SLUG_RE.match(slug):
            errors.append("المعرّف (الرابط) حروف إنجليزية صغيرة وأرقام وشرطات فقط، من ٣ إلى ٦٠ حرفًا.")
        elif database.slug_exists(slug, current_id):
            errors.append("هذا المعرّف مستخدم في مبادرة أخرى.")
        data["slug"] = slug
        return data, errors

    @app.route("/admin/initiatives/new", methods=["GET", "POST"])
    @admin_required
    def admin_initiative_new():
        form = {"status": "active", "category": "water"}
        if request.method == "POST":
            data, errors = parse_initiative_form(request.form)
            if not errors:
                database.save_initiative(data)
                flash("تمت إضافة المبادرة.", "ok")
                return redirect(url_for("admin_initiatives"))
            for e in errors:
                flash(e, "error")
            form = request.form
        return render_template("admin/initiative_form.html", form=form, item=None, updates=[])

    @app.route("/admin/initiatives/<int:iid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_initiative_edit(iid):
        item = database.get_initiative_by_id(iid)
        if not item:
            abort(404)
        form = item
        if request.method == "POST":
            data, errors = parse_initiative_form(request.form, iid)
            if not errors:
                database.save_initiative(data, iid)
                flash("تم حفظ التعديلات.", "ok")
                return redirect(url_for("admin_initiative_edit", iid=iid))
            for e in errors:
                flash(e, "error")
            form = request.form
        return render_template("admin/initiative_form.html", form=form, item=item,
                               updates=database.list_updates(iid))

    @app.post("/admin/initiatives/<int:iid>/delete")
    @admin_required
    def admin_initiative_delete(iid):
        if database.get_initiative_by_id(iid):
            database.delete_initiative(iid)
            flash("تم حذف المبادرة وكل تبرعاتها المسجلة.", "ok")
        return redirect(url_for("admin_initiatives"))

    @app.post("/admin/initiatives/<int:iid>/updates")
    @admin_required
    def admin_update_add(iid):
        body = clean(request.form.get("body"), 600, multiline=True)
        if not database.get_initiative_by_id(iid):
            abort(404)
        if body:
            database.add_update(iid, body)
            flash("نُشر التحديث في صفحة المبادرة.", "ok")
        else:
            flash("اكتب نص التحديث أولًا.", "error")
        return redirect(url_for("admin_initiative_edit", iid=iid) + "#updates")

    @app.get("/admin/donations")
    @admin_required
    def admin_donations():
        status = request.args.get("status", "")
        if status not in ("pending", "confirmed", "rejected"):
            status = ""
        return render_template("admin/donations.html", rows=database.list_donations(status or None),
                               status=status, over=database.admin_overview())

    @app.post("/admin/donations/<int:did>/status")
    @admin_required
    def admin_donation_status(did):
        status = request.form.get("status")
        if status in ("pending", "confirmed", "rejected"):
            database.set_donation_status(did, status)
            flash("تم تحديث حالة التبرع.", "ok")
        return redirect(request.form.get("back") if (request.form.get("back") or "").startswith("/admin")
                        else url_for("admin_donations"))

    @app.get("/admin/donations.csv")
    @admin_required
    def admin_donations_csv():
        def safe(v):  # منع حقن الصيغ في Excel
            v = str(v)
            return "'" + v if v[:1] in "=+-@\t\r" else v

        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["الرقم المرجعي", "التاريخ", "المبادرة", "المتبرع", "المبلغ", "الطريقة", "الحالة", "الرسالة"])
        for d in database.list_donations(limit=100000):
            w.writerow([d["reference"], d["created_at"], safe(d["initiative_title"]), safe(donor_label(d)),
                        d["amount"], PAYMENT_METHODS.get(d["method"], d["method"]), d["status"], safe(d["message"])])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv; charset=utf-8",
                        headers={"Content-Disposition": "attachment; filename=donations.csv"})

    @app.get("/admin/volunteers")
    @admin_required
    def admin_volunteers():
        return render_template("admin/volunteers.html", rows=database.list_volunteers())

    # ---------------------------------------------------------- الأخطاء
    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404, title="الصفحة غير موجودة",
                               text="الرابط الذي فتحته غير صحيح أو أُزيلت صفحته."), 404

    @app.errorhandler(400)
    def bad_request(_e):
        return render_template("error.html", code=400, title="تعذّر إتمام الطلب",
                               text="انتهت صلاحية الصفحة أو أُرسل الطلب بشكل غير صحيح. ارجع وحدّث الصفحة ثم حاول مرة أخرى."), 400

    @app.errorhandler(413)
    def too_large(_e):
        return render_template("error.html", code=413, title="الطلب كبير جدًا", text="قلّل حجم ما تكتبه وحاول مرة أخرى."), 413

    @app.errorhandler(500)
    def server_error(_e):
        return render_template("error.html", code=500, title="حدث خلل من جانبنا",
                               text="سجّلنا المشكلة. حاول مرة أخرى بعد قليل."), 500

    # ---------------------------------------------------------- أوامر
    @app.cli.command("set-admin-password")
    @click.option("--username", default="admin", show_default=True)
    @click.password_option()
    def set_admin_password(username, password):
        """تغيير كلمة مرور المدير (أو إنشاء مدير جديد)."""
        database.set_admin_password(username, password)
        click.echo("تم تحديث كلمة المرور.")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5000")),
            debug=os.getenv("FLASK_DEBUG") == "1")
