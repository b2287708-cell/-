"""تصنيفات المبادرات وطرق الدفع. عدّلها هنا وستظهر في كل الصفحات."""

CATEGORIES = {
    "water": {"label": "سقيا ومياه نظيفة", "color": "#0F8F95", "icon": "drop"},
    "food": {"label": "إطعام", "color": "#B9740F", "icon": "bowl"},
    "winter": {"label": "كسوة وشتاء", "color": "#4B55A8", "icon": "flake"},
    "education": {"label": "تعليم", "color": "#3F7D3A", "icon": "book"},
    "health": {"label": "صحة وعلاج", "color": "#8E3A99", "icon": "cross"},
    "shelter": {"label": "سكن وترميم", "color": "#7A5C3E", "icon": "house"},
    "care": {"label": "كفالة ورعاية", "color": "#C0587E", "icon": "heart"},
}

PAYMENT_METHODS = {
    "wallet": "محفظة إلكترونية",
    "instapay": "إنستا باي",
    "card": "بطاقة بنكية",
}
